const API_URL = "https://niswvnx32l.execute-api.us-east-1.amazonaws.com/transactions";
const cognitoConfig = {
  authority: "https://cognito-idp.us-east-1.amazonaws.com/us-east-1_UiMXf5eoZ",
  client_id: "7g7p3calpfv7ahg9t96tsk1c5s",
  redirect_uri: "http://127.0.0.1:5500/dashboard.html",
  response_type: "code",
  scope: "openid email phone",
};

const userManager = new oidc.UserManager(cognitoConfig);
// Grab the buttons and email display from the HTML
document.addEventListener("DOMContentLoaded", () => {
  const loginBtn = document.getElementById("login-btn");
  const logoutBtn = document.getElementById("logout-btn");
  const userEmailSpan = document.getElementById("user-email");


// When Login button is clicked, redirect to Cognito's login page
loginBtn.addEventListener("click", () => {
  userManager.signinRedirect();
});

// When Logout button is clicked, sign out and redirect back
logoutBtn.addEventListener("click", () => {
  userManager.signoutRedirect({
    post_logout_redirect_uri: "http://127.0.0.1:5500/dashboard.html"
  });
});
});
const category = document.getElementById("category");
const amount = document.getElementById("amount");
const type = document.getElementById("type");
const addBtn = document.getElementById("addBtn");

const balance = document.getElementById("balance");
const income = document.getElementById("income");
const expense = document.getElementById("expense");

const table = document.getElementById("transactionTable");

let transactions = [];

async function loadTransactions() {

    try {

        const res = await fetch(API_URL);
        transactions = await res.json();

        updateUI();

    } catch (err) {

        console.error(err);

    }

}

function updateUI() {

    table.innerHTML = "";

    let totalIncome = 0;
    let totalExpense = 0;

    transactions.forEach((item) => {

        const row = `
        <tr>
            <td>${item.title}</td>
            <td>₹${item.amount}</td>
            <td class="${item.type === "Income" ? "text-success" : "text-danger"}">
                ${item.type}
            </td>
        </tr>
        `;

        table.innerHTML += row;

        if(item.type==="Income")
            totalIncome += Number(item.amount);
        else
            totalExpense += Number(item.amount);

    });

    income.innerHTML = "₹" + totalIncome;
    expense.innerHTML = "₹" + totalExpense;
    balance.innerHTML = "₹" + (totalIncome-totalExpense);

}

addBtn.addEventListener("click", async ()=>{

    if(category.value==="" || amount.value===""){
        alert("Enter all details");
        return;
    }

    const body = {

        title: category.value,
        amount: Number(amount.value),
        type: type.value,
        date: new Date().toISOString().split("T")[0]

    };

    try{

        const res = await fetch(API_URL,{

            method:"POST",

            headers:{
                "Content-Type":"application/json"
            },

            body:JSON.stringify(body)

        });

        const data = await res.json();

        alert(data.message);

        category.value="";
        amount.value="";

        loadTransactions();

    }

    catch(err){

        console.error(err);

    }

});

loadTransactions();